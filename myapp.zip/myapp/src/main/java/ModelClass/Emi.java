package ModelClass;

import java.util.Date;

public class Emi {
    private double EmiAmount;
    private Date emiDueDate;
    private String status;
    private double principleComponent;
    private double interestAmount;
    private double penaltyCharges;

    public double getEmiAmount() {
        return EmiAmount;
    }

    public void setEmiAmount(double emiAmount) {
        EmiAmount = emiAmount;
    }

    public Date getEmiDueDate() {
        return emiDueDate;
    }

    public void setEmiDueDate(Date emiDueDate) {
        this.emiDueDate = emiDueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getPrincipleComponent() {
        return principleComponent;
    }

    public void setPrincipleComponent(double principleComponent) {
        this.principleComponent = principleComponent;
    }

    public double getInterestAmount() {
        return interestAmount;
    }

    public void setInterestAmount(double interestAmount) {
        this.interestAmount = interestAmount;
    }

    public double getPenaltyCharges() {
        return penaltyCharges;
    }

    public void setPenaltyCharges(double penaltyCharges) {
        this.penaltyCharges = penaltyCharges;
    }

    @Override
    public String toString() {
        return "Emi{" +
                "EmiAmount=" + EmiAmount +
                ", emiDueDate=" + emiDueDate +
                ", status='" + status + '\'' +
                ", principleComponent=" + principleComponent +
                ", interestAmount=" + interestAmount +
                ", penaltyCharges=" + penaltyCharges +
                '}';
    }
}

