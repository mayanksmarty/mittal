package ModelClass;

public abstract class SecuredLoan extends Loan {


    public SecuredLoan(laonstatus s) {
      //  super(s);
    }



    public abstract double calcloantovalue() ;



}

