package ModelClass;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public  abstract class Loan {
    private String customerId;
    private String LoanType;
    private String loanId;
    private double loanAmount;
    private int tenure;
    private double roi;
    public enum laonstatus {
        Approved, Rejected, Pending,Closed;
    }
private double maximumEligibleLoan;
    private double emiperMonth;
    private LocalDate loanDisbursalDate;
    private double maximumEmi;
    private int repaymentfrequency;
    private Date paymentdate;
    private double monthlyIncome;
    private double monthlyExpanse;
    ArrayList<Emi> list= new ArrayList<Emi>();

    public ArrayList<Emi> getList() {
        return list;
    }

    public void setList(ArrayList<Emi> list) {
        this.list = list;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public double getMonthlyExpanse() {
        return monthlyExpanse;
    }

    public void setMonthlyExpanse(double monthlyExpanse) {
        this.monthlyExpanse = monthlyExpanse;
    }

    public int getRepaymentfrequency() {
        return repaymentfrequency;
    }

    public void setRepaymentfrequency(int repaymentfrequency) {
        this.repaymentfrequency = repaymentfrequency;
    }

    public Date getPaymentdate() {
        return paymentdate;
    }

    public void setPaymentdate(Date paymentdate) {
        this.paymentdate = paymentdate;
    }

    laonstatus status;

    public laonstatus getStatus() {
        return status;
    }

    public void setStatus(laonstatus status) {
        this.status = status;
    }



    public String getLoanType() {
        return LoanType;
    }

    public void setLoanType(String loanType) {
        LoanType = loanType;
    }

    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public int getTenure() {
        return tenure;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public double getRoi() {
        return roi;
    }

    public void setRoi(double roi) {
        this.roi = roi;
    }

    public double getEmiperMonth() {
        return emiperMonth;
    }

    public void setEmiperMonth(double emiperMonth) {
        this.emiperMonth = emiperMonth;
    }

    public LocalDate getLoanDisbursalDate() {
        return loanDisbursalDate;
    }

    public void setLoanDisbursalDate(LocalDate loanDisbursalDate) {
        this.loanDisbursalDate = loanDisbursalDate;
    }

    public double getMaximumEmi() {
        return maximumEmi;
    }

    public void setMaximumEmi(double maximumEmi) {
        this.maximumEmi = maximumEmi;
    }

    public double getMaximumEligibleLoan() {
        return maximumEligibleLoan;
    }

    public void setMaximumEligibleLoan(double maximumEligibleLoan) {
        this.maximumEligibleLoan = maximumEligibleLoan;
    }

    @Override
    public String toString() {
        return "Customerloan{" +
                "LoanType='" + LoanType + '\'' +
                ", LoanId=" + loanId +
                ", loanAmount=" + loanAmount +
                ", tenure=" + tenure +
                ", roi=" + roi +
                ", monthlyIncome=" + monthlyIncome +
                ", monthlyExpanse=" + monthlyExpanse +
                ",  loanDisbursalDate=" + loanDisbursalDate +
                ", paymentdate=" + paymentdate +
                ", repaymentfrequency=" + repaymentfrequency +
                ", status=" + status +
                '}';
    }



    double calcemi() {

        double loanamount = getLoanAmount();

        double rate=getRoi()/(getRepaymentfrequency()*100);
        double b=1+rate;
        int tenure=12*getTenure();

        double installmentAmount =((loanamount*rate)/(1-(1/Math.pow(b,tenure))));
        return installmentAmount;

    }

    double calcloanamount() {
        double emi=((getMonthlyIncome()-getMonthlyExpanse())/2) - (getMonthlyIncome()* 0.20);

        double rate=getRoi()/1200;
        int tenure=12*getTenure();

        double Maximumemi = (emi * (Math.pow((1 + rate), tenure)-1)) /(rate* (Math.pow((1 + rate), tenure)));
        return Maximumemi;
    }

    void repymentschedule() {
        int residualvalue = 0;
        double interest;
        double principle;
        double loanamount = getLoanAmount();

        double rate=getRoi()/(getRepaymentfrequency()*100);
        double b=1+rate;
        int tenure=12*getTenure();

        double installmentAmount =((getLoanAmount()*rate)/(1-(1/Math.pow(b,tenure))));
        System.out.println("installment amount is " + installmentAmount);
        for (int installmentno = 1; installmentno <= tenure; installmentno++) {
            interest = (loanamount * getRoi())/1200;
            Emi emi = new Emi();
            principle = installmentAmount - interest;
            loanamount = loanamount - principle;

            emi.setInterestAmount(interest);
            emi.setPrincipleComponent(principle);
            list.add(emi);
            System.out.println("the installment for "+ " " + installmentno + " " + " year with insterst and principle"+ " " + interest + " " + " and " + " " + principle + " " + " and their installment(op)" + loanamount);

        }

    }

    /*void calcpenalty(double emi) {
        Scanner sc = new Scanner(System.in);
        LocalDate ld = getloanDisbursalDate();

        double r = getLoanAmount();
        for (long i = 1; i <= getTenure(); i++) {
            LocalDate duedate = ld.plusMonths(i);
            System.out.println(duedate);
            System.out.print("is emi is paid or not:-");
            String a = sc.nextLine();
            if (a.equals("yes") || a.equals("yes") || a.equals("YES") || a.equals("Y")) {
                double interest = r * (getRoi() / 12);
                double principle = emi - interest;
                r = r - principle;
            } else {

                System.out.println("Enter the payment date");
                setDay(sc.nextInt());
                System.out.println("Enter the payment month");
                setMonth(sc.nextInt());
                System.out.println("Enter the payment year");
                setYear(sc.nextInt());
                sc.nextLine();//for the next entry with the int and string
                LocalDate ld1 = LocalDate.of(getYear(), getMonth(), getDay());
                setPaymentdate(ld1);
                int l = duedate.getYear();
                int l3 = duedate.getMonthValue();
                int l4 = duedate.getDayOfMonth();
                int l5 = getPaymentdate().getYear();
                int l6 = getPaymentdate().getMonthValue();
                int l7 = getPaymentdate().getDayOfMonth();
                int q = l5 - l;
                int w = l6 - l3;
                int e = l7 - l4;

                double k = q * 360 + Math.abs(w) * 30 + Math.abs(e);
                double interest = emi * (k / 30);
                System.out.println(interest);
                i = i + w;


            }

        }
    }*/
}

