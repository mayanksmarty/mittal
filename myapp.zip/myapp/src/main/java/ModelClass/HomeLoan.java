package ModelClass;

public  class HomeLoan extends SecuredLoan {
    private String builderName;
    private int propertySize; private double propertyValue;

    public HomeLoan(laonstatus s) {
        super(s);
    }



    public String getBuilderName() {
        return builderName;
    }

    public void setBuilderName(String builderName) {
        this.builderName = builderName;
    }

    public int getPropertySize() {
        return propertySize;
    }

    public void setPropertySize(int propertySize) {
        this.propertySize = propertySize;
    }

    public double getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(double propertyValue) {
        this.propertyValue = propertyValue;
    }


/*    @Override
    public String toString() {
        return "Homeloan{" +
                "builderName='" + builderName + '\'' +
                ", propertySize=" + propertySize +
                ", propertyValue=" + propertyValue +
                ", status=" + status +
                '}';
    }*/

    @Override
    public double calcloantovalue() {
         double v = getLoanAmount()/getPropertyValue();
        return v;
    }

}
