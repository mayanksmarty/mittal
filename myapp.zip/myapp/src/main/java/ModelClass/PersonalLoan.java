package ModelClass;

public class PersonalLoan extends UnsecuredLoan {

    private String qualifiacation;
    private double workExperience;

    public PersonalLoan(Loan.laonstatus s) {
        super(s);
    }

    public String getQualifiacation() {
        return qualifiacation;
    }

    public void setQualifiacation(String qualifiacation) {
        this.qualifiacation = qualifiacation;
    }

    public double getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(double workExperience) {
        this.workExperience = workExperience;
    }


}
