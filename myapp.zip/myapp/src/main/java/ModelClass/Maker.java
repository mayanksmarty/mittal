package ModelClass;

public interface Maker {
    public boolean registerCustomer(Customer c);
    public boolean registerUser( user u);
    public Customer findCustomer( String name, String Password);
    public user findCustomer( String name, String Password,String role);

    public boolean applylaon(HomeLoan hl);
    public int applyloan(VeichleLoan vl);
    public int applyloan(PersonalLoan pl);
     public String trackloanstatus(String loanApplicationId);
   public  void getallactiveloandetail();
   public void getLoandetails(String loanAccountno);
    public void loanDisbursal(String loanId);
    public void payEMI(String loanAccountNumber, double emiAmount, int month);

}
