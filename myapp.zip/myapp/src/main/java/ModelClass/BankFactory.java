package ModelClass;

public class BankFactory {
    /*public Checker getShape(String shapeType) {
        if (shapeType == null) {
            return null;
        }
        else
        {
            return  Bank.getInstance();
        }
    }*/

    public static Bank getBank(){
        return  Bank.getInstance();
    }
}
