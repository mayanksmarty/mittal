package ModelClass;


import Controller.Dao;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.TreeMap;

public class Bank implements Maker,Checker{
    Loan[] cust = new Loan[100];
    TreeMap<String,Customer> hm=new TreeMap<String,Customer>();
    Customer c[]=new Customer[100];
    Emi emi = new Emi();

    int q = 0;

    Loan ln;
    private static Bank instance = null;
    private Bank() { }
    public static Bank getInstance() {
        if (instance == null) {
            instance = new Bank();
        }
        return instance;
    }
    public boolean registerCustomer(Customer c)
    {
        Dao d=new Dao();
        d.insert(c);

      hm.put(c.getCustomerId(),c);
      return true;
    }
    public boolean registerUser( user u)
    {
        Dao d=new Dao();
        d.insert1(u);
        return true;
    }
    public Customer findCustomer ( String name, String Password)
    {
        Dao d=new Dao();
      Customer c   =d.select1(name,Password);
        return  c;

       // return hm.get(CustomerID);
    }
    public user findCustomer ( String name, String Password,String role)
    {
        Dao d=new Dao();
        user u  =d.select(name,Password,role);
        return  u;

        // return hm.get(CustomerID);
    }


    public  boolean applylaon(HomeLoan hl) {

Dao d=new Dao();
 boolean r=d.applyloan(hl);
return r;
  }

    @Override
    public int applyloan(VeichleLoan vl) {
        return 0;
    }

    @Override
    public int applyloan(PersonalLoan pl) {
        return 0;
    }

    public  String trackloanstatus ( String loanApplicationId)

        {
            String p=null;
            //for (int i = 0; i < q; i++)
            for(Loan ln1 : cust) {

                if (loanApplicationId == ln1.getLoanId()) {
                   // System.out.println(ln1.getStatus());
                    p = ln1.getStatus().toString();
                    return p;
                }
                break;
            }
                return p;
        }
      public  void approverejectloan(String loanAppliocationId,double monthlyIncome,double monthlyExpanse) {

          cust[q].setMonthlyIncome(monthlyIncome);
          cust[q].setMonthlyExpanse(monthlyExpanse);


          for (int i = 0; i < q; i++) {
              if (loanAppliocationId == cust[i].getLoanId()) {
                  if (cust[i].getLoanAmount() < cust[i].calcloanamount()) {
                      cust[i].setStatus(Loan.laonstatus.Approved);
                      System.out.println(cust[i].getStatus());
                  } else {
                      try {
                          cust[i].setStatus(Loan.laonstatus.Rejected);
                          throw new LoannotApprovedException("pls enter again");

                      } catch (Exception e) {
                          System.out.println(e);
                      }
                  }
                  if (cust[i].getLoanType().equalsIgnoreCase("veichleloan")) {
                      VeichleLoan loans = (VeichleLoan) cust[i];
                      if (loans.calcloantovalue() < .80) {
                          cust[i].setStatus(Loan.laonstatus.Rejected);
                      }
                  }
                 /* if (cust[i].getLoanType().equalsIgnoreCase("homeloan")) {
                      LocalDate today = LocalDate.now();                          //Today's date
                      LocalDate birthday = (c[i].getDateOfBirth());  //Birth date

                      Period p = Period.between(birthday, today);
                      int years =p.getMonths();
                      LocalDate ld =cust[i]. getloanDisbursalDate();
                      int l = ld.getYear();

                      HomeLoan loans = (HomeLoan) cust[i];
                      if (loans.calcloantovalue() < .80 && (loans.getTenure()+years)>60) {
                          try {
                              cust[i].setStatus(Loan.laonstatus.Rejected);
                              throw new LoannotApprovedException("pls enter again");
                          }
                          catch (Exception e)
                          {
                              System.out.println(e);
                          }
                         
                      }
                  }*/
                  if (cust[i].getLoanType().equalsIgnoreCase("personalaloan")) {
                      PersonalLoan loans = (PersonalLoan) cust[i];
                      if (loans.getMonthlyIncome() * 12 > 500000 && loans.getWorkExperience() > 5) {
                          cust[i].setStatus(Loan.laonstatus.Rejected);
                      }


                  }
              }
          }
      }
    public void payEMI(String loanAccountNumber, double emiAmount, int month) {
        for(Loan ln: cust) {
            if (ln.getLoanId() == loanAccountNumber) {

                /*Emi emi = ln.getList().get(month - 1);

                double pendingEmiAmount = emi.getEmiAmount() + emi.getPenaltyCharges();
emi.setStatus("pending");
                if (emi.getStatus().equals("pending") && emiAmount == pendingEmiAmount) {
                    emi.setStatus("PAID");
                    emi.setEmiAmount(emiAmount);
                }*/


                if(emiAmount == emi.getEmiAmount())
                    emi.setStatus("Paid");
                else if(emi.getEmiAmount() < emiAmount) {
                    double pendingEmiAmount = (emi.getEmiAmount() - emiAmount) + emi.getPenaltyCharges();
                    emi.setPenaltyCharges(pendingEmiAmount);
                }
                else
                    emi.setStatus("Pending");
            }
        }
    }
    /*public void endOfDayProcess() {
        for (CustomerLoan loan: cust) {
            ArrayList<Emi> emiList = loan.getList();
            boolean duesSettled = true;
            LocalDate maturityDate = emiList.get(emiList.size() - 1).getEmiDueDate();

            double latePenalty = loan.calcpenalty();

            if (LocalDate.now().compareTo(maturityDate) == 0 && latePenalty == 0) {
                loan.setStatusOfLoan(LoanStatus.CLOSED);
            }
        }
    }*/
    /*void writeIntoFile(CustomerLoan loan)  {
        ObjectOutputStream objectOutputStream = Stream.get();
        try {
            if (loan instanceof HomeLoan) {
                HomeLoan homeLoan = (HomeLoan) loan;
                objectOutputStream.writeObject(homeLoan);
            }
            if (loan instanceof PersonalLoan) {
                PersonalLoan personalLoan = (PersonalLoan) loan;
                objectOutputStream.writeObject(personalLoan);
            }
            if (loan instanceof VeichleLoan) {
                VeichleLoan vehicleLoan = (VeichleLoan) loan;
                objectOutputStream.writeObject(vehicleLoan);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
*/

      public void loanDisbursal(String loanId)
      {
          for(Loan ln: cust)
          {
              if(ln.getLoanId() == loanId)
              {
                  if(ln.getStatus().equals(Loan.laonstatus.Approved))
                  {
                      ln.setStatus(Loan.laonstatus.Approved);
                   /*   ln.setLoanDisbursalDate(Date.now());*/
                      ln.calcemi();
                      emi.setEmiAmount(ln.calcemi());
                  }
              }
          }
      }


     public   void getallactiveloandetail()
        {
            for(int i=0;i<q;i++)
            {
                System.out.println(cust[i].toString());
            }
        }
    public    void getLoandetails(String loanAccountno)
        {
            for (Loan ln1 : cust) {
                if(loanAccountno==ln1.getLoanId())
                System.out.println(ln1);
                break;
            }

            }

     public   boolean removeloanAccount(String loanaccountno)
        { boolean flag=false;
            for (Loan ln1 : cust)

            {
                if(loanaccountno==ln1.getLoanId())
                {
         if(ln1.getStatus().equals(Loan.laonstatus.Closed)||ln1.getStatus().equals(Loan.laonstatus.Rejected))
                    {

                        /*for(int j = i; j< q; j++){
                            cust[i] = cust[i + 1];
                            flag=true;*/
                        flag=true;
                        break;
                        }

                    }


                }return flag;


        }


        }


