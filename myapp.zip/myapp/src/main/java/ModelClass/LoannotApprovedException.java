package ModelClass;

public class LoannotApprovedException extends Exception {
    LoannotApprovedException(String s)
    {
        System.out.println("pls enter again for the Loan");
        System.out.println(s);


    }


}
