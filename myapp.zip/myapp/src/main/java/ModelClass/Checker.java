package ModelClass;

public interface Checker {

    public void  approverejectloan(String loanAppliocationId, double monthlyIncome, double monthlyExpanse);
    public  void getallactiveloandetail();
    public void getLoandetails(String loanAccountno);
    public  boolean removeloanAccount(String loanAccountno);
    public void loanDisbursal(String loanId);

}
