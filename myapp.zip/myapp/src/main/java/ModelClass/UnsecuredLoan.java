package ModelClass;

public  abstract class UnsecuredLoan extends Loan {


    public UnsecuredLoan(laonstatus s) {
       // super(s);
    }
}
