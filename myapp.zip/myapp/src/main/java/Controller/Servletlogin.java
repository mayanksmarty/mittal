package Controller;

import ModelClass.BankFactory;
import ModelClass.Customer;
import ModelClass.Maker;
import ModelClass.user;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
@WebServlet("/login")
public class Servletlogin extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        String name=req.getParameter("uname");
        String Password=req.getParameter("psw");
        String Role=req.getParameter("c");
        BankFactory bf= new BankFactory();
        Maker m = bf.getBank();
        if(Role.equalsIgnoreCase("Customer"))
        {
            Customer c2=  m.findCustomer(name,Password);

            // Dao dt=new Dao();
         //    Customer c2= dt.select1(name,Password);
         //   System.out.println("ggg" + flag);
            if(c2== null)
            {
                PrintWriter out=resp.getWriter();
            //  req.setAttribute("msg","Wrong USername or Password");
            out.println("Wrong username and Password");
            RequestDispatcher dispatcher = req.getRequestDispatcher("Login.jsp");
            dispatcher.include( req, resp );


            }
            else
            {
                System.out.println(c2.getCustomerName());
                HttpSession session=req.getSession();

                session.setAttribute("name",c2.getCustomerName());
                session.setAttribute("password",c2.getPassword());
                session.setAttribute("mail",c2.getEmailAddress());
                session.setAttribute("contact", c2.getContactno());
                session.setAttribute("gender",c2.getGender());
                session.setAttribute("date",c2.getDateOfBirth());
                session.setAttribute("income",c2.getMonthlyIncome());
                session.setAttribute("expenses",c2.getTotalMonthlyExpense());
                session.setAttribute("qualification",c2.getQualification());
                session.setAttribute("experience",c2.getExperience());
                session.setAttribute("contact",c2.getContactno());

                session.setAttribute("uname",c2.getCustomerName());
                Cookie ck=new Cookie("name",name);
                resp.addCookie(ck);
               RequestDispatcher rd=req.getRequestDispatcher("customer.jsp");
               rd.forward(req,resp);
            }
        }
        else {
          user u=  m.findCustomer(name,Password,Role);
           /* boolean flag = dt.select(name, Password, Role);*/

            if(u==null) {
                PrintWriter out = resp.getWriter();
                //  req.setAttribute("msg","Wrong USername or Password");
                out.println("Wrong username and Password");
                RequestDispatcher dispatcher = req.getRequestDispatcher("Login.jsp");
                dispatcher.include(req, resp);
            }
            else
            {
                if (Role.equalsIgnoreCase("Maker")) {
                HttpSession session1=req.getSession();
                session1.setAttribute("uname",u.getCustomerName());
                        resp.sendRedirect("Maker.jsp");
                    } else if (Role.equalsIgnoreCase("Checker")) {
                        resp.sendRedirect("Checker.html");
                    } else {
                        resp.sendRedirect("Admin.html");
                    }
                }
            }




    }
}
