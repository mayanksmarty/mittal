package Controller;

import ModelClass.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet(urlPatterns = {"/homeloan", "/veichleloan","/personalloan"})
public class CustomerapplyloanServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        ServletContext sc=getServletContext();
        VeichleLoan vl=new VeichleLoan(Loan.laonstatus.Pending);
        PersonalLoan pl=new PersonalLoan(Loan.laonstatus.Pending);
        HomeLoan hl=new HomeLoan(Loan.laonstatus.Pending);
        BankFactory bf= new BankFactory();

        Maker m = bf.getBank();
        String loanType=req.getParameter("homeloan");
        System.out.println(loanType);
        String loanid=loanType+"Duplicatebank";
        HttpSession session1=req.getSession();
       String customerId=(String) session1.getAttribute("customerId");


        double loanamount=Double.parseDouble(req.getParameter("loanamount"));
        int tenure=Integer.parseInt(req.getParameter("tenure"));
        int repaymenyfrequency= Integer.parseInt(req.getParameter("repaymentfrequency"));


        double  homeloanroi=Double.parseDouble(sc.getInitParameter("Roi1"));
        double veichleroi=Double.parseDouble(sc.getInitParameter("Roi"));


        if(loanType.equalsIgnoreCase("homeloan")) {
            String buildername=req.getParameter("buildername");
            int propertysize=Integer.parseInt(req.getParameter("propertysize"));
            int propertyvalue=Integer.parseInt(req.getParameter("propertyvalue"));
            hl.setLoanId(loanid);
            hl.setLoanAmount(loanamount);
            hl.setTenure(tenure);
            hl.setBuilderName(buildername);
            hl.setPropertySize(propertysize);
            hl.setPropertyValue(propertyvalue);
            hl.setRepaymentfrequency(repaymenyfrequency);
            hl.setRoi(homeloanroi);
            hl.setStatus(Loan.laonstatus.Pending);
hl.setCustomerId(customerId);
           boolean f= m.applylaon(hl);
           if(f==true)
           {
               resp.sendRedirect("customer.jsp");
           }
           else
           {
               resp.sendRedirect("homeloan.jsp");
           }

        }
        else if(loanType.equalsIgnoreCase("vehicle"))
        {
            String modelno=req.getParameter("modelno");
            String category=req.getParameter("category");
            String manufacture=req.getParameter("manufacture");
            int yearofmanufacture=Integer.parseInt(req.getParameter("yearofmanufacture"));
            double assetvalue=Double.parseDouble(req.getParameter("assetvalue"));
            vl.setLoanId(loanid);
            vl.setLoanAmount(loanamount);
            vl.setTenure(tenure);
            vl.setRepaymentfrequency(repaymenyfrequency);
            vl.setAssetValue(assetvalue);
            vl.setManufacture(manufacture);
            vl.setVehicleCategory(category);
            vl.setYearOfManufacture(yearofmanufacture);
            vl.setVehicleModelNo(modelno);
            vl.setCustomerId(customerId);
            vl.setRoi(veichleroi);
            vl.setStatus(Loan.laonstatus.Pending);

            m.applyloan(vl);
        }
        else {
            pl.setLoanId(loanid);
            pl.setLoanAmount(loanamount);
            pl.setTenure(tenure);
            pl.setRepaymentfrequency(repaymenyfrequency);
            pl.setCustomerId(customerId);
            pl.setRoi(veichleroi);
            pl.setStatus(Loan.laonstatus.Pending);
            m.applyloan(pl);

        }









    }
}
