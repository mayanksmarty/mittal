package Controller;

import ModelClass.BankFactory;
import ModelClass.Customer;
import ModelClass.Maker;
import ModelClass.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

@WebServlet("/register")
public class ServletRegistration extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

         /*   resp.setContentType("text/html");*/

            String name=req.getParameter("name");
            String Password=req.getParameter("password");
            String mail=req.getParameter("gmail");
            String contact=(req.getParameter("contactno"));
            String gender=req.getParameter("g");
            String Role=req.getParameter("aorb");
            LocalDate date= LocalDate.parse(req.getParameter("date"));
            String customerId="Duplicatebank"+contact+name;
        HttpSession session1=req.getSession();
        session1.setAttribute("customerId",customerId);
            String userId="Duplicatebank"+name+Role;
        Customer c=new Customer();
        user u=new user();
        u.setUserId(userId);
        u.setCustomerName(name);
        u.setContactno(contact);
        u.setEmailAddress(mail);
        u.setPassword(Password);
        u.setDateOfBirth(date);
        u.setGender(gender);
        BankFactory bf= new BankFactory();
        Maker m = bf.getBank();
        c.setDateOfBirth(date);
        c.setCustomerName(name);
        c.setPassword(Password);
        c.setEmailAddress(mail);
        c.setContactno(contact);
        c.setGender(gender);
        c.setCustomerId(customerId);


        if (Role.equals("a")) {
            double income= Double.parseDouble(req.getParameter("income"));
            double expenses= Double.parseDouble(req.getParameter("expenses"));
            String qualification=req.getParameter("qualification");
            int experience = Integer.parseInt(req.getParameter("experience"));
            String profession=req.getParameter("profession");
            String designation=req.getParameter("designation");
            String companyname=req.getParameter("companyname");
            c.setMonthlyIncome(income);
            c.setTotalMonthlyExpense(expenses);
            c.setProfession(profession);
            c.setDesignation(designation);
            c.setCompanyName(companyname);
            c.setQualification(qualification);
            c.setExperience(experience);

        boolean b= m.registerCustomer(c);
        if(b==true)
        {

            resp.sendRedirect("Login.jsp");
        }
        else {
            resp.sendRedirect("signup.html");

        }

          /*  Dao dt=new Dao();

            dt.insert(c);
*/
        }
        else if(Role.equals("b"))
        { String Roles=req.getParameter("role");
           u.setRole(Roles);
        boolean b1= m.registerUser(u);
            if(b1==true)
            {
                resp.sendRedirect("Login.jsp");
            }
            else {
                resp.sendRedirect("signup.html");

            }


           /* Dao dt=new Dao();
            dt.insert1(date,name,Password,mail,gender,Roles,contact);*/

        }




           /* resp.sendRedirect("Login.jsp");*/
              /*PrintWriter out=resp.getWriter();
        out.println("<html><body><h1>First servlet</h1></body></html>");*/
        }
    }
