package Controller;

import ModelClass.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/update")
public class UpdateServletcustomer extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
        HttpSession session=req.getSession();
        String mail= (String)session.getAttribute("mail");
        String name= (String)session.getAttribute("name");
        String password=req.getParameter("password");
        System.out.println(mail);
        String contact=(req.getParameter("contactno"));
        double income= Double.parseDouble(req.getParameter("income"));
        double expenses= Double.parseDouble(req.getParameter("expenses"));
        String qualification=req.getParameter("qualification");
        int experience = Integer.parseInt(req.getParameter("experience"));
        Customer c1=new Customer();

        c1.setPassword(password);
        c1.setContactno(contact);
        c1.setMonthlyIncome(income);
        c1.setTotalMonthlyExpense(expenses);
        c1.setQualification(qualification);
        c1.setExperience(experience);
        c1.setEmailAddress(mail);
        c1.setCustomerName(name);
        System.out.println(c1);
        Dao dt=new Dao();
        boolean f=dt.update(c1);
        System.out.println(f);
        if(f==false)
        {
            resp.sendRedirect("editprofilecustomer.jsp");
        }
        else
        {
            resp.sendRedirect("customer.jsp");
        }
    }
}
