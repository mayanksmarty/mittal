package Controller;

import ModelClass.Customer;
import ModelClass.HomeLoan;
import ModelClass.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;


public class Dao {
    PreparedStatement psInsert;
    PreparedStatement psSelect;
    PreparedStatement psInsert1;
    PreparedStatement psSelect1;
    PreparedStatement psUpdate;
    PreparedStatement psApplyloan;


    public Dao() {
        Connection con = Connect.getConnection();
        try {
            psInsert = con.prepareStatement("insert into mayankcustomer values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            psInsert1 = con.prepareStatement("insert into mayankuser values(?,?,?,?,?,?,?,?)");
            psSelect = con.prepareStatement("select * from mayankuser where username = ? AND passwords = ? AND role =?");
            psSelect1 = con.prepareStatement("select * from mayankcustomer where username = ? AND passwords = ?");
            psUpdate = con.prepareStatement("update mayankcustomer set username=?,passwords=?,income=?,expenses=?,qualification =?,contactno=?,experience=? where mail=?");
            psApplyloan = con.prepareStatement("insert into mayankloan values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public int insert(Customer c) {
        int r = 0;
        Connection con = null;

        try {
            con = Connect.getConnection();

            psInsert.setDate(1, java.sql.Date.valueOf(c.getDateOfBirth()));
            psInsert.setString(2, c.getCustomerName());
            psInsert.setString(3, c.getPassword());
            psInsert.setString(4, c.getEmailAddress());
            psInsert.setString(5, c.getGender());

            psInsert.setDouble(6, c.getMonthlyIncome());
            psInsert.setDouble(7, c.getTotalMonthlyExpense());
            psInsert.setString(8, c.getQualification());


            psInsert.setInt(9, c.getExperience());
            psInsert.setString(10, c.getProfession());
            psInsert.setString(11, c.getDesignation());
            psInsert.setString(12, c.getCompanyName());

            psInsert.setString(13, c.getContactno());
            psInsert.setString(14, c.getCustomerId());
            r = psInsert.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return r;
    }

    public int insert1(user u) {
        int r = 0;
        Connection con = null;
        try {
            con = Connect.getConnection();

            psInsert1.setDate(1, java.sql.Date.valueOf(u.getDateOfBirth()));
            psInsert1.setString(2, u.getCustomerName());
            psInsert1.setString(3, u.getPassword());
            psInsert1.setString(4, u.getEmailAddress());
            psInsert1.setString(5, u.getGender());
            psInsert1.setString(6, u.getRole());
            psInsert1.setString(7, u.getContactno());
            psInsert1.setString(8, u.getUserId());
            r = psInsert1.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return r;

    }

    public user select(String username, String password, String role) {
        Connection con = null;
        user u1 = new user();
        try {
            con = Connect.getConnection();
            psSelect.setString(1, username);
            psSelect.setString(2, password);
            psSelect.setString(3, role);

            ResultSet rs = psSelect.executeQuery();
            if (rs.next()) {

                String uname = rs.getString(2);
                String passwords = rs.getString(3);
                String roles = rs.getString(6);
                if ((username.equals(uname)) && (password.equals(passwords)) && (roles.equals(role))) {
                    u1.setCustomerName(uname);
                    u1.setPassword(passwords);
                    u1.setRole(roles);
                    return u1;
                }

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public Customer select1(String username, String password) {
        Connection con = null;
        Customer c1 = new Customer();
        try {
            con = Connect.getConnection();
            psSelect1.setString(1, username);
            psSelect1.setString(2, password);


            ResultSet rs = psSelect1.executeQuery();
            if (rs.next()) {

                String uname = rs.getString(2);
                String passwords = rs.getString(3);
                LocalDate date = rs.getDate(1).toLocalDate();
                String mail = rs.getString(4);
                String gender = rs.getString(5);
                double income = rs.getDouble(6);
                double expenses = rs.getDouble(7);
                String qualification = rs.getString(8);
                int experience = rs.getInt(9);
                String contactno = rs.getString(13);


                if ((username.equals(uname)) && (password.equals(passwords))) {
                    c1.setCustomerName(uname);
                    c1.setPassword(passwords);
                    c1.setDateOfBirth(date);
                    c1.setExperience(experience);
                    c1.setEmailAddress(mail);
                    c1.setGender(gender);
                    c1.setMonthlyIncome(income);
                    c1.setTotalMonthlyExpense(expenses);
                    c1.setQualification(qualification);
                    c1.setContactno(contactno);
                    return c1;
                }

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public boolean update(Customer c) {
        boolean flag = false;
        int r = 0;
        Connection con = null;

        try {
            con = Connect.getConnection();

            psUpdate.setString(1, c.getCustomerName());
            psUpdate.setString(2, c.getPassword());
            psUpdate.setDouble(3, c.getMonthlyIncome());
            psUpdate.setDouble(4, c.getTotalMonthlyExpense());
            psUpdate.setString(5, c.getQualification());
            psUpdate.setString(6, c.getContactno());
            psUpdate.setInt(7, c.getExperience());
            psUpdate.setString(8, c.getEmailAddress());

            r = psUpdate.executeUpdate();
            flag = true;
            return flag;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    public boolean applyloan(HomeLoan hl) {
        int r = 0;
        boolean flag=false;
        Connection con = null;

        try {
            con = Connect.getConnection();
            psApplyloan.setString(1, hl.getLoanId());
            psApplyloan.setString(2, hl.getCustomerId());
            psApplyloan.setDouble(3, hl.getLoanAmount());
            psApplyloan.setString(4, hl.getLoanType());
            psApplyloan.setDouble(5, hl.getRoi());
            psApplyloan.setDouble(6, hl.getMaximumEmi());
            psApplyloan.setDouble(7,hl.getMaximumEligibleLoan());
            psApplyloan.setDouble(8, 0.0);
            psApplyloan.setDate(9, null);
            psApplyloan.setInt(10, hl.getTenure());
            psApplyloan.setInt(11, hl.getRepaymentfrequency());
            psApplyloan.setString(12, hl.getBuilderName());
            psApplyloan.setDouble(13, hl.getPropertyValue());
            psApplyloan.setDouble(14, hl.getPropertySize());
            psApplyloan.setString(15, null);
            psApplyloan.setString(16, null);
            psApplyloan.setString(17, null);
            psApplyloan.setString(18, null);
            psApplyloan.setDouble(19, 0.0);
            psApplyloan.setString(20, String.valueOf(hl.getStatus()));
            psApplyloan.executeUpdate();
            flag=true;
            return flag;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;

    }
}